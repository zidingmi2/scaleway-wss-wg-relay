use std::collections::HashMap;
use std::net::{IpAddr, SocketAddr};
use std::sync::Arc;

use log::{debug, error};
use tokio::task::JoinHandle;

use crate::config::{
    BindLocation, ResolvedServerConfig, ResolvedServerProxyConfig, ServerQuicConfig,
};
use crate::quic_stream::QuicStream;
use crate::resolver::Resolver;
use crate::rustls_config_util::try_create_server_config_with_source;
use crate::tcp::tcp_client_handler_factory::create_tcp_client_proxy_selector;
use crate::tcp::tcp_handler::TcpServerHandler;
use crate::tcp::tcp_server_handler_factory::{HandlerServices, create_tcp_server_handler_shared};
use crate::uuid_util::parse_uuid;

async fn start_quic_server(
    bind_address: SocketAddr,
    quic_server_config: Arc<dyn quinn::crypto::ServerConfig>,
    resolver: Arc<dyn Resolver>,
    server_handler: Arc<dyn TcpServerHandler>,
    num_endpoints: usize,
) -> std::io::Result<Vec<JoinHandle<()>>> {
    let mut join_handles = vec![];
    let mut server_config = quinn::ServerConfig::with_crypto(quic_server_config);
    let memory_bytes = crate::resources::configure_quic(&mut server_config, 100, 0);
    for endpoint in crate::listener_tasks::QuicListener::bind_all(
        bind_address,
        server_config,
        num_endpoints,
        memory_bytes,
    )? {
        let resolver = resolver.clone();
        let server_handler = server_handler.clone();
        let join_handle = tokio::spawn(async move {
            let mut tasks = crate::listener_tasks::ListenerTasks::immediate();
            loop {
                let conn = tokio::select! {
                    conn = endpoint.accept() => conn,
                    _ = tasks.join_next(), if !tasks.is_empty() => continue,
                };
                let Some(conn) = conn else { break };
                let Some(permit) =
                    crate::resources::try_connection(Some(conn.remote_address().ip()))
                else {
                    conn.refuse();
                    continue;
                };
                let conn = match conn.accept() {
                    Ok(conn) => conn,
                    Err(e) => {
                        debug!("QUIC accept failed: {e}");
                        continue;
                    }
                };
                let resolver = resolver.clone();
                let server_handler = server_handler.clone();
                tasks.spawn(async move {
                    let _permit = permit;
                    if let Err(e) = process_connection(resolver, server_handler, conn).await {
                        error!("Connection ended with error: {e}");
                    }
                });
            }
        });

        join_handles.push(join_handle);
    }

    Ok(join_handles)
}

async fn process_connection(
    resolver: Arc<dyn Resolver>,
    server_handler: Arc<dyn TcpServerHandler>,
    conn: quinn::Connecting,
) -> std::io::Result<()> {
    let connection = conn.await?;
    let mut tasks = tokio::task::JoinSet::new();

    loop {
        let accepted = tokio::select! {
            result = connection.accept_bi() => result,
            _ = tasks.join_next(), if !tasks.is_empty() => continue,
        };
        let stream = match accepted {
            Err(quinn::ConnectionError::ApplicationClosed { .. }) => {
                debug!("Connection closed");
                break;
            }
            Err(e) => {
                return Err(std::io::Error::other(format!("quic connection error: {e}")));
            }
            Ok(s) => s,
        };
        if crate::resources::limits()
            .max_streams_per_connection
            .is_some_and(|limit| tasks.len() >= limit)
        {
            continue;
        }
        let cloned_resolver = resolver.clone();
        let cloned_handler = server_handler.clone();
        let peer = connection.remote_address();
        tasks.spawn(async move {
            if let Err(e) = process_streams(cloned_resolver, cloned_handler, stream, peer).await {
                error!("Failed to process streams: {e}");
            }
        });
    }

    Ok(())
}

async fn process_streams(
    resolver: Arc<dyn Resolver>,
    server_handler: Arc<dyn TcpServerHandler>,
    (send, recv): (quinn::SendStream, quinn::RecvStream),
    peer: std::net::SocketAddr,
) -> std::io::Result<()> {
    crate::tcp::tcp_server::process_stream(
        QuicStream::from(send, recv).with_peer(peer),
        server_handler,
        resolver,
    )
    .await
}

pub async fn start_quic_servers(
    config: ResolvedServerConfig,
    resolver: Arc<dyn Resolver>,
) -> std::io::Result<Vec<JoinHandle<()>>> {
    let ResolvedServerConfig {
        bind_location,
        quic_settings,
        protocol,
        rules,
        sniff,
        ..
    } = config;

    println!("Starting {} QUIC server at {}", protocol, bind_location);

    let rules = rules.into_vec();
    // A direct entry must always exist
    assert!(!rules.is_empty());

    let bind_addresses = match bind_location {
        BindLocation::Unspecified {} => {
            return Err(std::io::Error::other("QUIC listener requires an address"));
        }
        // TODO: switch to non-blocking resolve?
        BindLocation::Address(addresses) => {
            let mut bind_addresses = Vec::new();
            for address in addresses.into_vec() {
                bind_addresses.extend(address.to_socket_addrs()?);
            }
            bind_addresses
        }
        BindLocation::Path(_) => {
            return Err(std::io::Error::other(
                "Cannot listen on path, QUIC does not have unix domain socket support",
            ));
        }
    };

    let ServerQuicConfig {
        certificate_source: _,
        certificate_binding,
        key_exchange_groups,
        cert,
        key,
        client_ca_certs,
        alpn_protocols,
        client_fingerprints,
        num_endpoints,
    } = quic_settings.unwrap();
    if let ResolvedServerProxyConfig::TuicV5 {
        zero_rtt_handshake, ..
    } = &protocol
    {
        key_exchange_groups.validate_zero_rtt(*zero_rtt_handshake)?;
    }

    // Certificates are already embedded as PEM data during config validation
    let cert_bytes = cert.as_bytes().to_vec();
    let key_bytes = key.as_bytes().to_vec();

    let mut processed_ca_certs = Vec::with_capacity(client_ca_certs.len());
    for cert in client_ca_certs.into_iter() {
        processed_ca_certs.push(cert.as_bytes().to_vec());
    }

    let alpn_protocols = if matches!(protocol, ResolvedServerProxyConfig::Xhttp(_))
        && alpn_protocols.is_unspecified()
    {
        vec!["h3".to_owned()]
    } else {
        alpn_protocols.into_vec()
    };
    let mut server_config = try_create_server_config_with_source(
        &cert_bytes,
        &key_bytes,
        processed_ca_certs,
        &alpn_protocols,
        &client_fingerprints.into_vec(),
        &key_exchange_groups,
        certificate_binding.as_ref(),
    )?;
    // QUIC manages early data separately; its TLS limit must be zero or u32::MAX.
    if !key_exchange_groups.requires_hybrid() {
        server_config.max_early_data_size = u32::MAX;
    }
    let server_config = Arc::new(server_config);

    let quic_server_config = crate::certificates::quic_config(server_config, certificate_binding)?;

    let client_proxy_selector = Arc::new(
        create_tcp_client_proxy_selector(rules.clone(), resolver.clone())?.with_sniff(sniff),
    );

    let mut handles = vec![];

    match protocol {
        ResolvedServerProxyConfig::Xhttp(config) => {
            if !matches!(
                config.http_version,
                crate::config::xhttp::XhttpVersion::Auto | crate::config::xhttp::XhttpVersion::H3
            ) {
                return Err(std::io::Error::other("QUIC XHTTP requires HTTP/3"));
            }
            if alpn_protocols != ["h3"] {
                return Err(std::io::Error::other("QUIC XHTTP ALPN must be h3"));
            }
            let max_requests = config.limits.request_limit().min(u32::MAX as usize) as u32;
            let service = Arc::new(crate::xhttp::XhttpServer::new(
                config,
                &client_proxy_selector,
                &resolver,
                None,
            )?);
            let mut endpoints = Vec::new();
            for address in bind_addresses {
                let mut config = quinn::ServerConfig::with_crypto(quic_server_config.clone());
                let memory_bytes = crate::resources::configure_quic(&mut config, max_requests, 16);
                let transport = Arc::get_mut(&mut config.transport).unwrap();
                transport
                    .max_concurrent_bidi_streams(max_requests.into())
                    .max_concurrent_uni_streams(16u32.into())
                    .datagram_receive_buffer_size(None)
                    .datagram_send_buffer_size(0);
                endpoints.extend(crate::listener_tasks::QuicListener::bind_all(
                    address,
                    config,
                    num_endpoints,
                    memory_bytes,
                )?);
            }
            for endpoint in endpoints {
                let service = service.clone();
                handles.push(tokio::spawn(async move {
                    let mut tasks = crate::listener_tasks::ListenerTasks::immediate();
                    loop {
                        let incoming = tokio::select! {
                            incoming = endpoint.accept() => incoming,
                            _ = tasks.join_next(), if !tasks.is_empty() => continue,
                        };
                        let Some(incoming) = incoming else {
                            break;
                        };
                        let Some(permit) =
                            crate::resources::try_connection(Some(incoming.remote_address().ip()))
                        else {
                            incoming.refuse();
                            continue;
                        };
                        let service = service.clone();
                        tasks.spawn(async move {
                            let _permit = permit;
                            if let Ok(connecting) = incoming.accept()
                                && let Ok(connection) = connecting.await
                                && let Err(error) = service.serve_h3(connection).await
                            {
                                log::debug!("XHTTP H3 carrier ended: {error}");
                            }
                        });
                    }
                }));
            }
        }
        ResolvedServerProxyConfig::Hysteria2 {
            password,
            udp_enabled,
        } => {
            // TODO: hash password instead of passing directly
            let hysteria2_password: Arc<str> = password.into();

            for bind_address in bind_addresses.into_iter() {
                let quic_server_config = quic_server_config.clone();
                let client_proxy_selector = client_proxy_selector.clone();
                let resolver = resolver.clone();
                let result = crate::hysteria2_server::start_hysteria2_server(
                    bind_address,
                    quic_server_config,
                    hysteria2_password.clone(),
                    client_proxy_selector,
                    resolver,
                    num_endpoints,
                    udp_enabled,
                )
                .await;
                collect_started_listeners(&mut handles, result).await?;
            }
        }
        ResolvedServerProxyConfig::TuicV5 {
            uuid,
            password,
            zero_rtt_handshake,
        } => {
            let uuid: Arc<[u8]> = parse_uuid(&uuid)?.into();
            let password: Arc<str> = password.into();
            for bind_address in bind_addresses.into_iter() {
                let quic_server_config = quic_server_config.clone();
                let client_proxy_selector = client_proxy_selector.clone();
                let resolver = resolver.clone();
                let result = crate::tuic_server::start_tuic_server(
                    bind_address,
                    quic_server_config,
                    uuid.clone(),
                    password.clone(),
                    client_proxy_selector,
                    resolver,
                    num_endpoints,
                    zero_rtt_handshake,
                )
                .await;
                collect_started_listeners(&mut handles, result).await?;
            }
        }
        tcp_protocol => {
            // Shares protocol state across ports without reusing an interface-specific UDP bind IP.
            let mut handlers: HashMap<IpAddr, Arc<dyn TcpServerHandler>> = HashMap::new();
            let mut services = HandlerServices::default();
            // Construct every handler before spawning listeners so errors cannot detach tasks.
            for bind_address in &bind_addresses {
                if let std::collections::hash_map::Entry::Vacant(entry) =
                    handlers.entry(bind_address.ip())
                {
                    entry.insert(
                        create_tcp_server_handler_shared(
                            tcp_protocol.clone(),
                            &client_proxy_selector,
                            &resolver,
                            Some(bind_address.ip()),
                            &mut services,
                        )?
                        .into(),
                    );
                }
            }
            for bind_address in bind_addresses.into_iter() {
                let tcp_handler = handlers[&bind_address.ip()].clone();
                let quic_server_config = quic_server_config.clone();
                let resolver = resolver.clone();
                let result = start_quic_server(
                    bind_address,
                    quic_server_config,
                    resolver,
                    tcp_handler,
                    num_endpoints,
                )
                .await;

                collect_started_listeners(&mut handles, result).await?;
            }
        }
    }

    Ok(handles)
}

async fn collect_started_listeners(
    handles: &mut Vec<JoinHandle<()>>,
    result: std::io::Result<Vec<JoinHandle<()>>>,
) -> std::io::Result<()> {
    match result {
        Ok(started) => {
            handles.extend(started);
            Ok(())
        }
        Err(error) => {
            for handle in handles.iter() {
                handle.abort();
            }
            for handle in handles.drain(..) {
                let _ = handle.await;
            }
            Err(error)
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::address::NetLocation;
    use crate::config::{ResolvedRuleConfig, Transport};
    use crate::option_util::{NoneOrSome, OneOrSome};
    use crate::resolver::NativeResolver;
    use std::time::Duration;

    async fn assert_partial_startup_cleanup(protocol: ResolvedServerProxyConfig) {
        let first = std::net::UdpSocket::bind("0.0.0.0:0").unwrap();
        let first_addr = first.local_addr().unwrap();
        let occupied = std::net::UdpSocket::bind("0.0.0.0:0").unwrap();
        let occupied_addr = occupied.local_addr().unwrap();
        let cert = rcgen::generate_simple_self_signed(vec!["localhost".into()]).unwrap();
        let mut rule = ResolvedRuleConfig::default();
        rule.compile(&mut crate::rules::Compiler::default())
            .unwrap();
        let config = ResolvedServerConfig {
            name: None,
            sniff: false,
            bind_location: BindLocation::Address(OneOrSome::Some(
                [first_addr, occupied_addr]
                    .into_iter()
                    .map(|addr| NetLocation::from_ip_addr(addr.ip(), addr.port()).into())
                    .collect(),
            )),
            protocol,
            transport: Transport::Quic,
            tcp_settings: None,
            quic_settings: Some(ServerQuicConfig {
                certificate_source: None,
                certificate_binding: None,
                key_exchange_groups: Default::default(),
                cert: cert.cert.pem(),
                key: cert.signing_key.serialize_pem(),
                alpn_protocols: NoneOrSome::One("h3".into()),
                client_ca_certs: NoneOrSome::None,
                client_fingerprints: NoneOrSome::None,
                num_endpoints: 2,
            }),
            rules: NoneOrSome::One(rule),
            dns: None,
        };
        drop(first);
        let error = start_quic_servers(config, Arc::new(NativeResolver::new()))
            .await
            .unwrap_err();
        assert_eq!(error.kind(), std::io::ErrorKind::AddrInUse);
        tokio::time::timeout(Duration::from_secs(1), async {
            loop {
                if let Ok(socket) = std::net::UdpSocket::bind(first_addr) {
                    break socket;
                }
                tokio::time::sleep(Duration::from_millis(10)).await;
            }
        })
        .await
        .expect("partial startup left the first QUIC address bound");
    }

    #[tokio::test]
    async fn partial_hysteria2_startup_releases_earlier_listeners() {
        assert_partial_startup_cleanup(ResolvedServerProxyConfig::Hysteria2 {
            password: "password".into(),
            udp_enabled: true,
        })
        .await;
    }

    #[tokio::test]
    async fn partial_tuic_startup_releases_earlier_listeners() {
        assert_partial_startup_cleanup(ResolvedServerProxyConfig::TuicV5 {
            uuid: "550e8400-e29b-41d4-a716-446655440000".into(),
            password: "password".into(),
            zero_rtt_handshake: false,
        })
        .await;
    }

    #[tokio::test]
    async fn partial_generic_quic_startup_releases_earlier_listeners() {
        assert_partial_startup_cleanup(ResolvedServerProxyConfig::Http {
            username: None,
            password: None,
        })
        .await;
    }
}

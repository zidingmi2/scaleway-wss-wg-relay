use std::{
    io::{self, IoSliceMut},
    net::SocketAddr,
    pin::Pin,
    sync::Arc,
    task::{Context, Poll},
};

use blake2::{Blake2b, Digest, digest::consts::U32};
use quinn::{
    AsyncUdpSocket, UdpPoller,
    udp::{RecvMeta, Transmit},
};
use rand::Rng;

use crate::config::quic_client::Secret;

pub(crate) const OVERHEAD: u16 = 8;
const SALT_LEN: usize = OVERHEAD as usize;

#[derive(Debug)]
pub(crate) struct Salamander {
    inner: Arc<dyn AsyncUdpSocket>,
    password: Secret,
}

fn key(password: &str, salt: &[u8]) -> [u8; 32] {
    let mut hash = Blake2b::<U32>::new();
    hash.update(password.as_bytes());
    hash.update(salt);
    hash.finalize().into()
}

fn xor(data: &mut [u8], key: &[u8; 32]) {
    for chunk in data.chunks_mut(32) {
        for (byte, key) in chunk.iter_mut().zip(key) {
            *byte ^= key;
        }
    }
}

fn decode(password: &str, data: &mut [u8]) -> Option<usize> {
    let size = data.len().checked_sub(SALT_LEN).filter(|size| *size > 0)?;
    let key = key(password, &data[..SALT_LEN]);
    data.copy_within(SALT_LEN.., 0);
    xor(&mut data[..size], &key);
    Some(size)
}

// GRO may combine datagrams even when transmit segmentation is disabled.
fn decode_segments(password: &str, data: &mut [u8], stride: usize) -> Option<(usize, usize)> {
    if stride == 0 || stride >= data.len() {
        let length = decode(password, data)?;
        return Some((length, length));
    }
    let decoded_stride = stride.checked_sub(SALT_LEN).filter(|size| *size > 0)?;
    let mut out = 0;
    for start in (0..data.len()).step_by(stride) {
        let end = (start + stride).min(data.len());
        if let Some(size) = decode(password, &mut data[start..end]) {
            data.copy_within(start..start + size, out);
            out += size;
        } else if end != data.len() {
            return None;
        }
    }
    (out > 0).then_some((out, decoded_stride))
}

fn decode_batch(
    password: &str,
    bufs: &mut [IoSliceMut<'_>],
    meta: &mut [RecvMeta],
    count: usize,
) -> usize {
    let mut kept = 0;
    for index in 0..count {
        let Some((length, stride)) = decode_segments(
            password,
            &mut bufs[index][..meta[index].len],
            meta[index].stride,
        ) else {
            continue;
        };
        if kept != index {
            let (before, after) = bufs.split_at_mut(index);
            before[kept][..length].copy_from_slice(&after[0][..length]);
            meta[kept] = meta[index];
        }
        meta[kept].len = length;
        meta[kept].stride = stride;
        kept += 1;
    }
    kept
}

impl Salamander {
    pub fn wrap(inner: Arc<dyn AsyncUdpSocket>, password: Secret) -> Arc<dyn AsyncUdpSocket> {
        Arc::new(Self { inner, password })
    }
}

impl AsyncUdpSocket for Salamander {
    fn create_io_poller(self: Arc<Self>) -> Pin<Box<dyn UdpPoller>> {
        self.inner.clone().create_io_poller()
    }
    fn try_send(&self, transmit: &Transmit<'_>) -> io::Result<()> {
        if transmit
            .segment_size
            .is_some_and(|size| size < transmit.contents.len())
        {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                "Salamander transmit segmentation disabled",
            ));
        }
        let mut data = vec![0; transmit.contents.len() + SALT_LEN];
        rand::rng().fill_bytes(&mut data[..SALT_LEN]);
        let key = key(&self.password.0, &data[..SALT_LEN]);
        data[SALT_LEN..].copy_from_slice(transmit.contents);
        xor(&mut data[SALT_LEN..], &key);
        self.inner.try_send(&Transmit {
            contents: &data,
            segment_size: None,
            ..*transmit
        })
    }
    fn poll_recv(
        &self,
        cx: &mut Context<'_>,
        bufs: &mut [IoSliceMut<'_>],
        meta: &mut [RecvMeta],
    ) -> Poll<io::Result<usize>> {
        // Bound work under a flood of malformed packets without losing a wakeup.
        for _ in 0..32 {
            let count = std::task::ready!(self.inner.poll_recv(cx, bufs, meta))?;
            let kept = decode_batch(&self.password.0, bufs, meta, count);
            if kept > 0 {
                return Poll::Ready(Ok(kept));
            }
        }
        cx.waker().wake_by_ref();
        Poll::Pending
    }
    fn local_addr(&self) -> io::Result<SocketAddr> {
        self.inner.local_addr()
    }
    fn max_transmit_segments(&self) -> usize {
        1
    }
    fn max_receive_segments(&self) -> usize {
        self.inner.max_receive_segments()
    }
    fn may_fragment(&self) -> bool {
        self.inner.may_fragment()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn apernet_known_answer() {
        // apernet/hysteria extras/v2/obfs WrapPacketConnSalamander output.
        let mut wire = [0xf0, 0xf5, 0x80, 0xb2, 0xd9, 0x0e, 0x4b, 0x57, 0xe8];
        assert_eq!(decode("salamander psk", &mut wire), Some(1));
        assert_eq!(wire[0], 1);
    }

    #[test]
    fn key_matches_blake2b_256_at_block_boundaries() {
        // Matches Go's blake2b.Sum256(password || salt), not keyed BLAKE2 or truncation.
        let salt = [0, 1, 2, 3, 4, 5, 6, 7];
        for (length, expected) in [
            (
                4,
                "82cfc0da318bf7df292252caf279cc2745976b5ec7a7159ac0a99a2e324480fd",
            ),
            (
                120,
                "8e749c3a841d4cd8e51bfe851e3b4c601b86616dd8370e519218c986749e4b03",
            ),
            (
                121,
                "197256e932bfd3e67648765d2ee9629f42878492d956c540615fa9b3ed58971c",
            ),
            (
                248,
                "4d6e52065ab48cfb903e6c0ac0a9789767d576ba240d431b145754bd7bd6b2ae",
            ),
        ] {
            let actual: String = key(&"p".repeat(length), &salt)
                .iter()
                .map(|byte| format!("{byte:02x}"))
                .collect();
            assert_eq!(actual, expected, "password length {length}");
        }
    }

    fn wire(data: &[u8]) -> Vec<u8> {
        let mut wire = vec![1; 8];
        wire.extend_from_slice(data);
        xor(&mut wire[8..], &key("password", &[1; 8]));
        wire
    }

    #[test]
    fn coalesced_receive_compacts_payloads_and_metadata() {
        let mut bad = [0; 8];
        let mut good = [wire(&[1; 100]), wire(&[2; 100]), wire(&[3; 40])].concat();
        // Receive buffers supplied by Quinn have equal capacity.
        let mut first = vec![0; good.len()];
        first[..8].copy_from_slice(&bad);
        let mut bufs = [IoSliceMut::new(&mut first), IoSliceMut::new(&mut good)];
        let mut meta = [
            RecvMeta {
                len: 8,
                stride: 8,
                ..Default::default()
            },
            RecvMeta {
                len: 264,
                stride: 108,
                addr: "127.0.0.1:443".parse().unwrap(),
                ..Default::default()
            },
        ];
        assert_eq!(decode_batch("password", &mut bufs, &mut meta, 2), 1);
        assert_eq!(
            (meta[0].len, meta[0].stride, meta[0].addr.port()),
            (240, 100, 443)
        );
        assert_eq!(
            &bufs[0][..240],
            [&[1; 100][..], &[2; 100], &[3; 40]].concat()
        );
        assert!(decode("password", &mut bad).is_none());
    }
}

//! TUN device configuration types.
//!
//! TUN (network TUNnel) devices are virtual network interfaces that operate at
//! the IP layer (Layer 3). Unlike regular server configs that bind to a
//! TCP/UDP port, TUN servers receive raw IP packets from applications.
//!
//! # Platform Differences
//!
//! - **Linux**: Creates a new TUN device with the specified name and address.
//!   Requires root privileges or `CAP_NET_ADMIN` capability.
//!
//! - **Android**: Requires a file descriptor from `VpnService.Builder.establish()`.
//!   The VPN configuration (routes, DNS, etc.) is handled by the Android VpnService.
//!
//! - **iOS**: Requires a file descriptor from `NEPacketTunnelProvider.packetFlow`.
//!   Use `packet_information: true` if using the socket FD directly.

use std::net::{IpAddr, SocketAddr};

use serde::{Deserialize, Serialize};

use crate::option_util::NoneOrSome;

use super::common::default_true;
use super::dns::DnsConfig;
use super::rules::RuleConfig;
use super::selection::ConfigSelection;

#[derive(Debug, Clone, PartialEq, Eq, Deserialize, Serialize)]
#[serde(default, deny_unknown_fields)]
pub struct LinuxTunOptions {
    pub table: u32,
    pub rule_priority: u32,
    pub capture_mark: u32,
    pub bypass_mark: u32,
    pub mark_mask: u32,
}

impl Default for LinuxTunOptions {
    fn default() -> Self {
        Self {
            table: 12000,
            rule_priority: 12000,
            capture_mark: 0x20000000,
            bypass_mark: 0x40000000,
            mark_mask: 0x60000000,
        }
    }
}

#[derive(Debug, Clone, Deserialize, Serialize)]
#[serde(default, deny_unknown_fields)]
pub struct TunResourceLimits {
    pub tcp_buffer_size: usize,
    /// Optional growth ceiling for each of the four userspace TCP buffers.
    /// PacketStack reserves the initial allocation for every configured flow
    /// before allowing established flows to consume the growth pool.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub tcp_buffer_max_size: Option<usize>,
    pub tcp_memory_bytes: Option<usize>,
    pub max_tcp_connections: Option<usize>,
    pub max_udp_sessions: Option<usize>,
    pub max_udp_destinations: Option<usize>,
    pub max_udp_destinations_per_session: Option<usize>,
    /// Shared outbound payload allowance across session and destination queues.
    pub max_udp_queued_bytes: Option<usize>,
}

impl Default for TunResourceLimits {
    fn default() -> Self {
        Self {
            tcp_buffer_size: 32 * 1024,
            tcp_buffer_max_size: None,
            tcp_memory_bytes: None,
            max_tcp_connections: None,
            max_udp_sessions: None,
            max_udp_destinations: None,
            max_udp_destinations_per_session: None,
            max_udp_queued_bytes: None,
        }
    }
}

impl TunResourceLimits {
    pub fn validate(&self) -> std::io::Result<()> {
        if !(1024..=16 * 1024 * 1024).contains(&self.tcp_buffer_size)
            || self
                .tcp_memory_bytes
                .is_some_and(|bytes| bytes / 4 < self.tcp_buffer_size)
            || self.max_tcp_connections == Some(0)
            || self.max_udp_sessions == Some(0)
            || self.max_udp_destinations == Some(0)
            || self.max_udp_destinations_per_session == Some(0)
            || self.max_udp_queued_bytes.is_some_and(|bytes| bytes < 65535)
        {
            return Err(std::io::Error::new(
                std::io::ErrorKind::InvalidInput,
                "invalid TUN resource limits",
            ));
        }
        if let Some(maximum) = self.tcp_buffer_max_size {
            let base = self
                .max_tcp_connections
                .and_then(|count| count.checked_mul(4))
                .and_then(|count| count.checked_mul(self.tcp_buffer_size));
            if !(self.tcp_buffer_size..=16 * 1024 * 1024).contains(&maximum)
                || base
                    .zip(self.tcp_memory_bytes)
                    .is_none_or(|(base, total)| base > total)
            {
                return Err(std::io::Error::new(
                    std::io::ErrorKind::InvalidInput,
                    "dynamic TCP buffers require an explicit connection cap and enough memory for all initial buffers",
                ));
            }
        }
        Ok(())
    }

    pub fn tcp_connection_limit(&self) -> Option<usize> {
        let memory_limit = self
            .tcp_memory_bytes
            .map(|bytes| bytes / 4 / self.tcp_buffer_size);
        match (self.max_tcp_connections, memory_limit) {
            (Some(count), Some(memory)) => Some(count.min(memory)),
            (count, None) => count,
            (None, memory) => memory,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn tun_admission_is_unlimited_by_default() {
        let limits: TunResourceLimits = serde_yaml::from_str("{}").unwrap();
        limits.validate().unwrap();
        assert_eq!(limits.tcp_connection_limit(), None);
        assert_eq!(limits.max_udp_sessions, None);
        assert_eq!(limits.max_udp_destinations, None);
        assert_eq!(limits.max_udp_destinations_per_session, None);
        assert_eq!(limits.max_udp_queued_bytes, None);
    }

    #[test]
    fn explicit_tcp_count_and_memory_limits_apply_independently() {
        let mut limits = TunResourceLimits {
            max_tcp_connections: Some(1024),
            ..Default::default()
        };
        assert_eq!(limits.tcp_connection_limit(), Some(1024));
        limits.tcp_memory_bytes = Some(32 * 1024 * 1024);
        assert_eq!(limits.tcp_connection_limit(), Some(256));
        limits.max_tcp_connections = Some(16);
        assert_eq!(limits.tcp_connection_limit(), Some(16));
    }

    #[test]
    fn tcp_budget_counts_all_four_buffers_and_validates_limits() {
        let mut limits = TunResourceLimits::default();
        limits.tcp_memory_bytes = Some(8 * limits.tcp_buffer_size);
        assert_eq!(limits.tcp_connection_limit(), Some(2));
        limits.validate().unwrap();
        limits.tcp_memory_bytes = Some(1);
        assert!(limits.validate().is_err());
        limits.tcp_buffer_size = 0;
        assert!(limits.validate().is_err());
    }

    #[test]
    fn udp_queue_budget_must_fit_a_maximum_datagram() {
        let mut limits = TunResourceLimits {
            max_udp_queued_bytes: Some(65535),
            ..Default::default()
        };
        limits.validate().unwrap();
        limits.max_udp_queued_bytes = Some(65534);
        assert!(limits.validate().is_err());
    }

    #[test]
    fn dynamic_tcp_growth_reserves_initial_capacity_for_all_connections() {
        let mut limits = TunResourceLimits {
            tcp_buffer_size: 32 * 1024,
            tcp_buffer_max_size: Some(1024 * 1024),
            tcp_memory_bytes: Some(32 * 1024 * 1024),
            max_tcp_connections: Some(80),
            ..Default::default()
        };
        limits.validate().unwrap();
        assert_eq!(limits.tcp_connection_limit(), Some(80));
        limits.tcp_memory_bytes = Some(80 * 4 * 32 * 1024 - 1);
        assert!(limits.validate().is_err());
        limits.tcp_memory_bytes = Some(32 * 1024 * 1024);
        limits.max_tcp_connections = None;
        assert!(limits.validate().is_err());
    }
}

fn default_mtu() -> u16 {
    // Platform-specific MTU defaults based on sing-box research:
    // - iOS Network Extension: 4064 max (4096 - 32 byte UTUN_IF_HEADROOM_SIZE)
    //   Performance drops significantly above this value
    // - Android: 9000 (some devices report ENOBUFS with 65535)
    // - Other platforms: 1500 (standard Ethernet MTU)
    #[cfg(target_os = "ios")]
    return 4064;
    #[cfg(target_os = "android")]
    return 9000;
    #[cfg(not(any(target_os = "ios", target_os = "android")))]
    return 1500;
}

/// TUN device server configuration.
///
/// This is a top-level config type (not nested under ServerConfig) because TUN
/// devices are fundamentally different from TCP/UDP servers:
/// - No bind address (binds to a virtual network device, not a socket)
/// - No transport layer (receives raw IP packets)
/// - Platform-specific device creation (Linux name/address vs iOS/Android raw_fd)
#[derive(Debug, Clone, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
#[serde(bound(deserialize = "R: Deserialize<'de>, D: Deserialize<'de>"))]
pub struct TunRecord<R, D> {
    #[serde(default, skip_serializing_if = "super::common::is_false")]
    pub auto_route: bool,
    #[serde(default, skip_serializing_if = "super::common::is_false")]
    pub auto_redirect: bool,
    /// Defaults to true in managed mode. False leaves host resolver settings untouched.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub auto_dns: Option<bool>,
    /// Dual-stack interface CIDRs for managed mode, separate from manual device configuration.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub addresses: Vec<ipnetwork::IpNetwork>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub route_address: Vec<ipnetwork::IpNetwork>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub route_exclude_address: Vec<ipnetwork::IpNetwork>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub bootstrap_dns: Vec<SocketAddr>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub linux: Option<LinuxTunOptions>,
    /// Intercepts captured TCP/UDP DNS independently of synthetic addressing.
    /// Omitted follows the selected fake-IP policy for unmanaged TUNs.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub dns_hijack: Option<bool>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub name: Option<String>,
    #[serde(default, skip_serializing_if = "super::common::is_false")]
    pub sniff: bool,
    /// Automatic for owned Linux devices. False disables TCPv4 transmit offload.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub segmentation_offload: Option<bool>,
    #[serde(default)]
    pub resource_limits: TunResourceLimits,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub packet_information: Option<bool>,
    /// TUN device name (Linux only, e.g., "tun0").
    /// Ignored on iOS/Android where the device is provided via device_fd.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub device_name: Option<String>,

    /// Raw file descriptor for the TUN device (iOS/Android).
    /// - **Android**: from `VpnService.Builder.establish()`
    /// - **iOS**: from `NEPacketTunnelProvider.packetFlow`
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub device_fd: Option<i32>,

    /// TUN device IP address (e.g., "10.0.0.1").
    /// - **Linux**: Sets the device's IP address
    /// - **iOS/Android**: Informational only (address is set by VPN service)
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub address: Option<IpAddr>,

    /// TUN device netmask (e.g., "255.255.255.0").
    /// - **Linux**: Sets the device's netmask
    /// - **iOS/Android**: Informational only
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub netmask: Option<IpAddr>,

    /// TUN device destination/gateway (Linux only).
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub destination: Option<IpAddr>,

    /// MTU size for the TUN interface.
    /// Default: 1500
    #[serde(default = "default_mtu")]
    pub mtu: u16,

    /// Enable TCP connection handling.
    /// Default: true
    #[serde(default = "default_true")]
    pub tcp_enabled: bool,

    /// Enable UDP packet handling.
    /// Default: true
    #[serde(default = "default_true")]
    pub udp_enabled: bool,

    /// Enable ICMP (ping) handling.
    /// Note: ICMP requires TCP to be enabled as well.
    /// Default: true
    #[serde(default = "default_true")]
    pub icmp_enabled: bool,

    /// Routing rules for traffic coming through the TUN device.
    /// Default: Allow all traffic directly
    #[serde(
        alias = "rule",
        default,
        skip_serializing_if = "NoneOrSome::is_unspecified"
    )]
    pub rules: NoneOrSome<R>,

    /// DNS configuration for this TUN server (optional).
    /// Can reference a dns_group by name or specify inline DNS servers.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub dns: Option<D>,
}

pub type TunConfig = TunRecord<ConfigSelection<RuleConfig>, DnsConfig>;

impl<R, D> TunRecord<R, D> {
    pub(crate) fn has_managed_options(&self) -> bool {
        self.auto_route
            || self.auto_redirect
            || self.auto_dns.is_some()
            || self.linux.is_some()
            || !self.addresses.is_empty()
            || !self.bootstrap_dns.is_empty()
            || !self.route_address.is_empty()
            || !self.route_exclude_address.is_empty()
    }

    pub(crate) fn virtual_dns_addresses(&self) -> impl Iterator<Item = IpAddr> + '_ {
        self.addresses
            .iter()
            .filter(|_| self.auto_route && (self.auto_dns.unwrap_or(true) || self.auto_redirect))
            .filter_map(|network| next_ip_address(network.ip()))
    }
}

pub(crate) fn next_ip_address(address: IpAddr) -> Option<IpAddr> {
    match address {
        IpAddr::V4(ip) => u32::from(ip).checked_add(1).map(|ip| IpAddr::V4(ip.into())),
        IpAddr::V6(ip) => u128::from(ip)
            .checked_add(1)
            .map(|ip| IpAddr::V6(ip.into())),
    }
}
